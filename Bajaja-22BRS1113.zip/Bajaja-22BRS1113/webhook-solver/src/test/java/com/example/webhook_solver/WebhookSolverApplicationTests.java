package com.example.webhook_solver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebhookSolverApplicationTests {

	@Test
	void contextLoads() {
	}

}
