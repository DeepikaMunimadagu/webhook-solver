package com.example.webhook_solver.runner;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.example.webhook_solver.services.WebhookService;

@Component
public class WebhookRunner implements ApplicationRunner {
    private final WebhookService webhookService;

    public WebhookRunner(WebhookService webhookService) {
        this.webhookService = webhookService;
    }

    @Override
    public void run(ApplicationArguments args) {
        webhookService.executeFlow();
        System.exit(0);
    }
}
