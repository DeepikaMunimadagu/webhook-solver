package com.example.webhook_solver.services;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.webhook_solver.model.GenerateWebhookResponse;

@Service
public class WebhookService {

    private final RestTemplate restTemplate;

    @Value("${app.name}")
    private String name;
    @Value("${app.regNo}")
    private String regNo;
    @Value("${app.email}")
    private String email;

    public WebhookService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public void executeFlow() {
        try {
            // 1. Generate webhook
            String url = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            Map<String, String> body = Map.of("name", name, "regNo", regNo, "email", email);
            HttpEntity<Map<String, String>> request = new HttpEntity<>(body, headers);

            ResponseEntity<GenerateWebhookResponse> resp = restTemplate.postForEntity(url, request, GenerateWebhookResponse.class);
            if (!resp.getStatusCode().is2xxSuccessful()) throw new RuntimeException("Failed: " + resp.getStatusCode());
            GenerateWebhookResponse data = resp.getBody();
            if (data == null) throw new RuntimeException("No data received");

            // 2. Load SQL file
            String sqlPath = lastTwoDigitsOdd(regNo) ? "src/main/resources/sql/question1.sql" : "src/main/resources/sql/question2.sql";
            String finalQuery = Files.readString(Paths.get(sqlPath)).trim();

            // 3. Submit SQL
            HttpHeaders submitHeaders = new HttpHeaders();
            submitHeaders.setContentType(MediaType.APPLICATION_JSON);
            submitHeaders.set("Authorization", data.getAccessToken());
            Map<String, String> submitBody = Map.of("finalQuery", finalQuery);
            HttpEntity<Map<String, String>> submitRequest = new HttpEntity<>(submitBody, submitHeaders);

            ResponseEntity<String> submitResp = restTemplate.postForEntity(data.getWebhook(), submitRequest, String.class);
            System.out.println("Submission Response: " + submitResp.getStatusCode() + " -> " + submitResp.getBody());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean lastTwoDigitsOdd(String reg) {
        String digits = reg.replaceAll("\\D", "");
        if (digits.length() < 2) return false;
        int lastTwo = Integer.parseInt(digits.substring(digits.length() - 2));
        return lastTwo % 2 == 1;
    }
}
